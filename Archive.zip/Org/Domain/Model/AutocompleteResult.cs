﻿using System;
namespace Org
{
    public class AutocompleteResult
    {
        public string Id { get; set; }
        public string Value { get; set; }
        public string SubValue { get; set; }
        public string PictureUrl { get; set; }
    }
}
