﻿using System;
namespace Org
{
    public class Employee
    {
        public string Igg { get; set; }
        public string PopsId { get; set; }
        public string Email { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Manager { get; set; }
        public string Department { get; set; }
        public string Country { get; set; }
        public string Contract { get; set; }
        public string Title { get; set; }
        public string PictureUrl { get; set; }
        public string City { get; set; }
    }
}
