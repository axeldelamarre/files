﻿using System;
namespace Org.Domain.Model
{
    public class EmployeeRecord
    {
        public string Email { get; set; }
        public string Igg { get; set; }
        public string PopsId { get; set; }
        public string Sip { get; set; }
    }
}
