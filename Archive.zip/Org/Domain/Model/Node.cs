﻿using System.Collections.Generic;
using System.Linq;

namespace Org
{
    public class Node
    {
        public string Value { get; set; }
        public Node Parent { get; set; }
        public IList<Node> Children { get; set; } = new List<Node>();

        public override string ToString()
        {
            var children = string.Join(", ", Children.Select(child => child.Value));
            return $"Node({Value}, Parent={Parent?.Value}, Children={children})";
        }
    }
}
