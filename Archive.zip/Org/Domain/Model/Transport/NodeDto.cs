﻿using System;
using System.Collections.Generic;

namespace Org
{
    public class NodeDto
    {
        public string Id { get; set; }
        //public string FirstName { get; set; }
        //public string LastName { get; set; }
        //public string Department { get; set; }
        public IList<NodeDto> Children { get; set; }
    }
}
