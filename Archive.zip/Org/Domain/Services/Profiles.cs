﻿using System;
namespace Org.Domain.Services
{
    public class Profiles
    {
        public Profiles()
        {
        }
    }
}
