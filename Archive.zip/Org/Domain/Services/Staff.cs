﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Org
{
    using StatsDictionary = DefaultDictionary<string, DefaultDictionary<string, DefaultDictionary<string, int>>>;

    public static class Staff
    {
        private static readonly IList<string> TopBusinessLines = new[] { "MARK", "GBIS", "ITEC" };

        public static IList<Employee> LoadEmployees()
        {
            var employees = new List<Employee>
            {
                new Employee { Email = "slawomir.krupa@sgcib.com", Country="FR", Department="MARK/EQD", Contract="fte" },
                new Employee { Email = "john.fitzgerald@sgcib.com", Manager = "slawomir.krupa@sgcib.com", Country="US", Department="GLFI/EQD", Contract="fte" },
                new Employee { Email = "simon.letort@sgcib.com", Manager = "slawomir.krupa@sgcib.com", Country="US", Department="GLFI/FIC", Contract="fte" },
                new Employee { Email = "kamalesh.rao@sgcib.com", Manager = "simon.letort@sgcib.com", Country="US", Department="MARK/EQD", Contract="fte" },
                new Employee { Email = "sandhya.sriraman@sgcib.com", Manager = "kamalesh.rao@sgcib.com", Country="US", Department="CORI/EQD", Contract="fte" },
                new Employee { Email = "kevin.slader@sgcib.com", Manager = "kamalesh.rao@sgcib.com", Country="HK", Department="MARK/EQD", Contract="fte" },
                new Employee { Email = "eli.mensch-ext@sgcib.com", Manager = "kevin.slader@sgcib.com", Country="HK", Department="MARK/EQD", Contract="intern" },
                new Employee { Email = "hadrien.royal@sgcib.com", Manager = "simon.letort@sgcib.com", Country="HK", Department="ITEC/EQD", Contract="fte" },
                new Employee { Email = "brandon.nguyen@sgcib.com", Manager = "hadrien.royal@sgcib.com", Country="HK", Department="ITEC/MKT", Contract="fte" },
                new Employee { Email = "valeska.guegnon@sgcib.com", Manager = "hadrien.royal@sgcib.com", Country="HK", Department="HUMN/EQD", Contract="fte" },
            };
            return employees;
        }

        public static string GetBusinessLine(string department)
        {
            if (department != null && !department.Contains(" "))
            {
                return department.Split('/')[0];
            }
            return department;
        }

        public static IList<string> GetBusinessLines(IList<string> departments)
        {
            var businessLines = new SortedSet<string>(departments.Select(GetBusinessLine));
            return TopBusinessLines.Concat(businessLines.Except(TopBusinessLines)).ToList();
        }

        public static IList<string> GetAggregateDepartments(IList<string> departments)
        {
            return departments; // TODO
        }

        public static StatsDictionary GetCountryStats(IList<Employee> employees)
        {
            var stats = new DefaultDictionary<string, DefaultDictionary<string, DefaultDictionary<string, int>>>();
            foreach (var employee in employees)
            {
                var businessLine = GetBusinessLine(employee.Department);
                stats[employee.Country][businessLine][employee.Contract] += 1;
            }
            return stats;
        }

        public static IDictionary<string, AutocompleteResult> GetAutocompleteResults(IList<Employee> employees, IList<string> aggregateDepartments, IDictionary<string, string> cities)
        {
            var employeeResults = employees.Select(employee => new AutocompleteResult
            {
                Id = employee.Email,
                Value = $"{employee.FirstName} {employee.LastName}",
                SubValue = $"{employee.Department?.Split('/')[0] ?? ""}, {employee.Title}",
                PictureUrl = employee.PictureUrl,
            });
            var departmentResults = aggregateDepartments.Select(department => new AutocompleteResult
            {
                Id = department,
                Value = department,
            });
            var cityResults = cities.Select(pair => new AutocompleteResult
            {
                Id = pair.Key,
                Value = pair.Value,
            });
            return employeeResults.Concat(departmentResults).Concat(cityResults).ToDictionary(result => result.Id, result => result);
        }
    }
}
