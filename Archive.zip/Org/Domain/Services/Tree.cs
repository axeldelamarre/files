﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Org
{
    public class Tree
    {
        public Node Root { get; set; }
        public IDictionary<string, Node> Nodes { get; set; }

        public Tree(IDictionary<string, Employee> employees)
        {
            Nodes = employees.Keys.ToDictionary(email => email, email => new Node { Value = email });
            foreach (var node in Nodes.Values)
            {
                var managerEmail = employees[node.Value].Manager;
                if (managerEmail != null && Nodes.TryGetValue(managerEmail, out var parent))
                {
                    node.Parent = parent;
                    parent.Children.Add(node);
                }
            }
            Root = Nodes["slawomir.krupa@sgcib.com"];
        }

        /// <summary>
        /// entourage: (noun) a group of people attending or surrounding an important person.
        /// </summary>
        public Node GetEntourage(string value)
        {
            var self = Nodes[value];
            var parent = self.Parent ?? self;
            var parentOut = new Node { Value = parent.Value };
            foreach (var sibling in parent.Children)
            {
                var siblingOut = new Node { Value = sibling.Value };
                if (sibling.Value == value)
                {
                    siblingOut.Children = self.Children.Select(child => new Node { Value = child.Value }).ToList();
                }
                parentOut.Children.Add(siblingOut);
            }
            return parentOut;
        }

        /// <summary>
        /// For a given list of nodes, return the smallest subtree containing these nodes
        /// </summary>
        public Node GetRelations(IList<string> values)
        {
            var seen = new Dictionary<string, Node>();
            foreach (var value in values)
            {
                var child = Nodes[value];
                var childOut = new Node { Value = value };
                seen[value] = childOut;
                foreach (var parent in GetParentNodes(child))
                {
                    if (seen.TryGetValue(parent.Value, out var parentOut))
                    {
                        if (!parentOut.Children.Select(node => node.Value).Contains(child.Value))
                        {
                            parentOut.Children.Add(childOut);
                        }
                    }
                    else
                    {
                        parentOut = new Node { Value = parent.Value, Children = new List<Node> { childOut } };
                        seen[parent.Value] = parentOut;
                    }
                    (child, childOut) = (parent, parentOut);
                }
            }
            var rootOut = seen[Root.Value];
            while (!values.Contains(rootOut.Value) && rootOut.Children.Count == 1)
            {
                rootOut = rootOut.Children[0];
            }
            return rootOut;
        }

        public IEnumerable<Node> GetParentNodes(Node node, bool strict = true)
        {
            if (!strict)
            {
                yield return node;
            }
            var parent = node.Parent;
            while (parent != null)
            {
                yield return parent;
                parent = parent.Parent;
            }
        }

        public IDictionary<string, int> CountSizes()
        {
            var sizes = new DefaultDictionary<string, int>();
            var stack = new Stack<Node>();

            stack.Push(Root);
            while (stack.Any())
            {
                var node = stack.Pop();
                var value = node.Value;
                sizes[value]++;

                foreach (var child in node.Children)
                {
                    stack.Push(child);
                }
            }
            return sizes;
        }
    }
}
