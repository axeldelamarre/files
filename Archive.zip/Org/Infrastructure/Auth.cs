﻿using System;
namespace Org.Infrastructure
{
    public class Auth
    {
        public Auth()
        {
        }
    }
}
