﻿using System;
using System.Collections.Generic;
using System.Linq;
using Org.Domain.Model;

namespace Org
{
    using StatsDictionary = DefaultDictionary<string, DefaultDictionary<string, DefaultDictionary<string, int>>>;

    /// <summary>
    /// Heap-stored collections for faster access
    /// </summary>
    public static class Caches
    {
        public static bool IsLoaded { get; private set; } = false;

        public static IDictionary<string, Employee> Employees { get; private set; }
        public static IDictionary<string, EmployeeRecord> EmployeeRecords { get; private set; }
        public static IList<string> Departments { get; private set; }
        public static IList<string> AggregateDepartments { get; private set; }
        public static IList<string> BusinessLines { get; private set; }
        public static IDictionary<string, string> Cities { get; private set; }
        public static IDictionary<string, List<Employee>> CountryEmployees { get; private set; }
        public static IDictionary<string, AutocompleteResult> AutocompleteResults { get; private set; }
        public static StatsDictionary Stats { get; private set; }

        private static IDictionary<string, string> IggEmails { get; set; }
        private static IDictionary<string, string> EmailIggs { get; set; }
        private static IDictionary<string, string> PopsIdEmails { get; set; }
        private static IDictionary<string, string> EmailPopsIds { get; set; }

        public static void Initialize()
        {
            var employees = Staff.LoadEmployees();
            Employees = employees.ToDictionary(employee => employee.Email, employee => employee);
            EmployeeRecords = new Dictionary<string, EmployeeRecord> { };
            Departments = new SortedSet<string>(employees.Select(employee => employee.Department)).ToList();
            AggregateDepartments = Staff.GetAggregateDepartments(Departments);
            BusinessLines = Staff.GetBusinessLines(Departments);
            Cities = employees.Select(employee => employee.City).Where(city => city != null).ToDictionary(city => city.Replace(' ', '-'), city => city);
            CountryEmployees = employees.GroupBy(employee => employee.Country).ToDictionary(group => group.Key, group => group.ToList());
            AutocompleteResults = Staff.GetAutocompleteResults(employees, AggregateDepartments, Cities);
            Stats = Staff.GetCountryStats(employees);

            IsLoaded = true;
        }

    }
}
