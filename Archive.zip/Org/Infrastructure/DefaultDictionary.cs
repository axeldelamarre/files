﻿using System;
using System.Collections.Generic;

namespace Org
{
    public class DefaultDictionary<TKey, TValue> : Dictionary<TKey, TValue> where TValue : new()
    {
        public new TValue this[TKey key]
        {
            get
            {
                if (!TryGetValue(key, out var value))
                {
                    value = new TValue();
                    Add(key, value);
                }
                return value;
            }
            set { base[key] = value; }
        }
    }
}
