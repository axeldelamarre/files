﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Org
{
    public class OrgChart
    {
        public IDictionary<string, Employee> Employees { get; }
        public Tree Tree { get; }

        public OrgChart(ICollection<Employee> employees)
        {
            Employees = employees.ToDictionary(employee => employee.Email, employee => employee);
            Tree = new Tree(Employees);
        }

        public NodeDto Serialize(Node node)
        {
            var employee = Employees[node.Value];
            var dtoNode = new NodeDto
            {
                Id = employee.Email,
                //FirstName = employee.FirstName,
                //LastName = employee.LastName,
                //Department = employee.Department,
                Children = node.Children.Select(Serialize).ToList(),
            };
            return dtoNode;
        }
    }
}
