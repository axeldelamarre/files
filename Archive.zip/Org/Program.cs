﻿using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace Org
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Caches.Initialize();
            var orgchart = new OrgChart(Caches.Employees.Values);
            //var node = orgchart.Tree.Nodes["slawomir.krupa@sgcib.com"];
            //var node = orgchart.Tree.GetEntourage("valeska.guegnon@sgcib.com");
            var emails = new[] { "simon.letort@sgcib.com", "eli.mensch-ext@sgcib.com", "sandhya.sriraman@sgcib.com" };
            var node = orgchart.Tree.GetRelations(emails);
            //var result = orgchart.Serialize(node);
            //var result = Staff.ComputeCountryStats(employees);
            var result = orgchart.Tree.CountSizes();

            var settings = new JsonSerializerSettings
            {
                ContractResolver = new CamelCasePropertyNamesContractResolver(),
                Formatting = Formatting.Indented,
            };
            var obj = JsonConvert.SerializeObject(result, settings);
            Console.WriteLine($"Hello World: {obj}");
        }
    }
}
