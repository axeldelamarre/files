#!/bin/bash
python3.6 -m pip install --system --target . requests
python3.6 -m pip install --system --target . dill
