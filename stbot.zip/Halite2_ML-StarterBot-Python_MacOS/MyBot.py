import bot_light
bot_light.LightBot(network_name='self', name='MyBot').play()
