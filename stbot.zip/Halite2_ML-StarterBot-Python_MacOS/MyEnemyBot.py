import bot_light
bot_light.LightBot(network_name='enemy', name='MyEnemyBot').play()
