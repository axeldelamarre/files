import json
import shutil
import pathlib
import itertools
import subprocess
import datetime as dt

import tsmlstarterbot.train_self


def play_game(map_width, map_height, bot_commands):
    game_run_command = [
        f'./halite',
        f'--no-compression',
        f'--quiet',
        f'--timeout',
        f'--dimensions',
        f'{map_width} {map_height}',
    ]
    for bot_command in bot_commands:
        game_run_command.append(bot_command)
    return subprocess.Popen(game_run_command, universal_newlines=True, stdout=subprocess.PIPE)


def parallel_run():
    map_width, map_height = 240, 160
    bot_commands = [
        'python MyBot.py',
        'python MyBotLongTraining.py',
    ]
    processes = [play_game(map_width, map_height, bot_commands) for _ in range(4)]
    for process in processes:
        process.wait()
    for process in processes:
        out, _ = process.communicate()
        result = json.loads(out)
        yield result


def winner(result):
    return next(tag for tag, stat in result['stats'].items() if stat['rank'] == 1)


def main():
    start = dt.datetime.now()
    results = list(itertools.chain(*(parallel_run() for _ in range(1))))
    win_rate = sum(1 for tag in map(winner, results) if tag == '0') / len(results)
    with open('stats.csv', 'a') as fp:
        print(win_rate)
        fp.write(f'{win_rate}\n')
    tsmlstarterbot.train_self.main()
    shutil.make_archive(f'replays-learned/replays-{int(dt.datetime.now().timestamp())}', 'zip', 'replays')
    for path in pathlib.Path('replays').glob('*.hlt'):
        path.unlink()
    print('took', dt.datetime.now() - start)


if __name__ == '__main__':
    main()
