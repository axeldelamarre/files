import json
import shutil
import pathlib
import itertools
import subprocess
import datetime as dt
import multiprocessing
import concurrent.futures

import requests

import tsmlstarterbot.train_self


def play_game(map_width, map_height, bot_commands):
    game_run_command = [
        f'./halite',
        f'--no-compression',
        f'--quiet',
        f'--timeout',
        f'--dimensions',
        f'{map_width} {map_height}',
    ]
    for bot_command in bot_commands:
        game_run_command.append(bot_command)
    return subprocess.Popen(game_run_command, universal_newlines=True, stdout=subprocess.PIPE)


def run(length):
    map_width, map_height = 240, 160
    bot_commands = [
        'python MyBot.py',
        'python MyEnemyBot.py',
    ]
    results = []
    for i in range(length):
        with open(f'perf.log', 'a') as fp:
            fp.write(f'{dt.datetime.now()}: {i}: start\n')
        process = play_game(map_width, map_height, bot_commands)
        out, _ = process.communicate()
        result = json.loads(out)
        print(i, result['stats'])
        with open(f'perf.log', 'a') as fp:
            fp.write(f'{dt.datetime.now()}: {i}: end\n')
        results.append(result)
    return results


def parallel_run(n_threads, run_length):
    start = dt.datetime.now()
    args = [run_length] * n_threads
    with concurrent.futures.ThreadPoolExecutor() as executor:
        results = executor.map(run, args)
    results = list(itertools.chain(*results))
    win_rate = sum(1 for tag in map(winner, results) if tag == '0') / len(results)
    with open('stats.csv', 'a') as fp:
        print('win rate', win_rate)
        fp.write(f'{win_rate}\n')
    print('parallel_run took', dt.datetime.now() - start)
    return win_rate


def winner(result):
    return next(tag for tag, stat in result['stats'].items() if stat['rank'] == 1)


def train():
    tsmlstarterbot.train_self.main()
    shutil.make_archive(f'replays-learned/replays-{int(dt.datetime.now().timestamp())}', 'zip', 'replays')
    for path in pathlib.Path('replays').glob('*.hlt'):
        path.unlink()
    requests.get('http://localhost:5000/reload/self')


def main():
    for epoch in itertools.count():
        win_rate = parallel_run(n_threads=multiprocessing.cpu_count()/2, run_length=10)
        print('epoch', epoch, 'win rate', win_rate)
        train()


if __name__ == '__main__':
    main()
