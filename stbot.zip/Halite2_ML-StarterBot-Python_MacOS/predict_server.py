import sys
import json
import pickle
import logging

import flask

from tsmlstarterbot import neural_net

logging.getLogger('werkzeug').setLevel(logging.ERROR)

app = flask.Flask(__name__)

nn_self = neural_net.NeuralNet(cached_model='models/model_self.ckpt')
nn_enemy = neural_net.NeuralNet(cached_model='models/model_long_training.ckpt')


@app.route('/ping', methods=['GET'])
def ping():
    return 'pong'


@app.route('/predict', methods=['POST'])
def predict():
    features = pickle.loads(flask.request.data)
    return json.dumps(state)



@app.route('/gym-to-halite', methods=['GET', 'POST'])
def gym_to_halite():
    if flask.request.method == 'GET':
        episode = state['episode']
        while state['gym-to-halite'] is None:
            if episode != state['episode']:
                return ''
        value = state['gym-to-halite']
        state['gym-to-halite'] = None
        return value
    else:
        # assert state['gym-to-halite'] is None, 'gym-to-halite overwrote value'
        # print(f"state['gym-to-halite'] = {flask.request.data}, type={type(flask.request.data)}")
        state['gym-to-halite'] = flask.request.data
        return ''


@app.route('/kill', methods=['GET'])
def kill():
    sys.exit(0)


def main():
    app.run(debug=False, threaded=True)


if __name__ == '__main__':
    main()
