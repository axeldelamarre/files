import sys
import pickle
import datetime as dt

import flask
import numpy as np

from tsmlstarterbot import common, neural_net

# logging.getLogger('werkzeug').setLevel(logging.ERROR)

app = flask.Flask(__name__)

networks = {}


@app.route('/ping', methods=['GET'])
def ping():
    return 'pong'


@app.route('/reload/<network_name>', methods=['GET'])
def reload(network_name):
    start = dt.datetime.now()
    network = neural_net.NeuralNet(cached_model=f'models/model_{network_name}.ckpt')
    networks[network_name] = network
    random_input_data = np.random.rand(common.PLANET_MAX_NUM, common.PER_PLANET_FEATURES)
    predictions = network.predict(random_input_data)
    assert len(predictions) == common.PLANET_MAX_NUM
    print(f'reload {network_name} took', dt.datetime.now() - start)
    return 'ok'


@app.route('/predict/<network>', methods=['POST'])
def predict(network):
    features = pickle.loads(flask.request.data)
    predictions = networks[network].predict(features)
    return pickle.dumps(predictions)


@app.route('/kill', methods=['GET'])
def kill():
    sys.exit(0)


def main():
    for name in ['self', 'enemy']:
        reload(name)

    from tornado.wsgi import WSGIContainer
    from tornado.httpserver import HTTPServer
    from tornado.ioloop import IOLoop

    http_server = HTTPServer(WSGIContainer(app))
    http_server.listen(5000)
    IOLoop.instance().start()
    # app.run(debug=False, threaded=True)


if __name__ == '__main__':
    main()
